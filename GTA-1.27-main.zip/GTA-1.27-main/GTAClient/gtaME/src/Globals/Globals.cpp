#include "stdafx.h"

CGlobals Globals;
