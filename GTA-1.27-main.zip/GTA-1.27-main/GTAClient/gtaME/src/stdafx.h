#pragma once

#include <xtl.h>
#include <stdio.h>
#include <string>
#include <xbdm.h>
#include <xkelib.h>

#include "Globals/Globals.h"
#include "Tools/Tools.h"
#include "Hooks/Hooks.h"
