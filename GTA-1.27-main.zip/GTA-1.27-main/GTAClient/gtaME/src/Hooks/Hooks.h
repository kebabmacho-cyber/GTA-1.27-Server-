#pragma once

class CHooks {
public:
	bool Initialize();
};

extern CHooks Hooks;
